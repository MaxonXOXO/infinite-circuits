// src/components/Header.jsx
import React, { useState, useEffect } from "react";

export default function Header() {
  const colors = [
    { name: "red", hex: "#e53935" },
    { name: "green", hex: "#00c853" },
    { name: "black", hex: "#000000" },
    { name: "blue", hex: "#2962ff" },
  ];

  const [selected, setSelected] = useState("black");
  const [lastSaved, setLastSaved] = useState(null);
  const [saveStatus, setSaveStatus] = useState("idle");

  // Emit selection for Canvas to pick up
  useEffect(() => {
    const ev = new CustomEvent("trace-color-changed", { detail: selected });
    window.dispatchEvent(ev);
  }, [selected]);

  // Listen for save events from Canvas
  useEffect(() => {
    const handleSaveEvent = (e) => {
      setLastSaved(new Date().toLocaleTimeString());
      setSaveStatus("saved");
      
      // Reset status after 2 seconds
      setTimeout(() => setSaveStatus("idle"), 2000);
    };

    const handleSavingEvent = (e) => {
      setSaveStatus("saving");
    };
    
    window.addEventListener("canvas-saved", handleSaveEvent);
    window.addEventListener("canvas-saving", handleSavingEvent);
    
    return () => {
      window.removeEventListener("canvas-saved", handleSaveEvent);
      window.removeEventListener("canvas-saving", handleSavingEvent);
    };
  }, []);

  return (
    <header
      className="header"
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "8px 12px",
        borderBottom: "1px solid rgba(0,0,0,0.06)",
        background: "#110e1fff",
        zIndex: 1000,
      }}
    >
      <div className="header-left" style={{ display: "flex", alignItems: "center" }}>
        <h1 className="text-3xl font-bold" style={{ margin: 0, color: "#006cd1ff" }}>
          Infinite Circuits
        </h1>
      </div>

      <div
        className="header-right"
        style={{ display: "flex", alignItems: "center", gap: 12 }}
      >
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <button className="btn" disabled style={{ padding: "6px 10px" }}>
            New
          </button>
          <button 
            className="btn" 
            onClick={() => {
              const event = new CustomEvent("trigger-save");
              window.dispatchEvent(event);
            }}
            style={{ padding: "6px 10px", cursor: "pointer" }}
            title="Save (Ctrl+S)"
          >
            Save
          </button>
          <button className="btn" disabled style={{ padding: "6px 10px" }}>
            Help
          </button>
        </div>

        {/* Save status indicator */}
        {saveStatus === "saving" && (
          <span style={{ fontSize: "12px", color: "#9ca3af", marginLeft: "8px" }}>
            Saving...
          </span>
        )}
        {saveStatus === "saved" && lastSaved && (
          <span style={{ fontSize: "12px", color: "#00c853", marginLeft: "8px" }}>
            Saved {lastSaved}
          </span>
        )}

        {/* Trace color selector */}
        <div style={{ display: "flex", gap: 8, alignItems: "center", marginLeft: 8 }}>
          {colors.map((c) => (
            <button
              key={c.name}
              onClick={() => setSelected(c.name)}
              title={c.name}
              style={{
                width: 26,
                height: 26,
                borderRadius: 999,
                border: selected === c.name ? "2px solid #111" : "2px solid rgba(0,0,0,0.12)",
                background: c.hex,
                padding: 0,
                cursor: "pointer",
                boxSizing: "border-box",
              }}
            />
          ))}
        </div>
      </div>
    </header>
  );
}