export default function About() {
  return (
    <div>
      <h1 className="text-2xl font-bold">About</h1>
      <p>This is the about page.</p>
    </div>
  );
}
