export default function Home() {
  return (
    <div>
      <h1 className="text-2xl font-bold">Home</h1>
      <p>Welcome to WireframeX!</p>
    </div>
  );
}